from flask import render_template, Blueprint, redirect, url_for

Known = Blueprint("Known", __name__)


@Known.route("/known")
def Index():
    return render_template("known/known.html")

@Known.route("/fractures")
def Fracture():
    return render_template("known/fractures.html")

@Known.route("/bleeding")
def Bleeding():
    return render_template("known/bleeding.html")

@Known.route("/burns")
def Burns():
    return render_template("known/burns.html")

@Known.route("/choking")
def Choking():
    return render_template("known/choking.html")

@Known.route("/heartattacks")
def HeartAttack():
    return render_template("known/heartattack.html")

@Known.route("/strokes")
def Strokes():
    return render_template("known/stroke.html")