feather.replace()
document.getElementById("treatment").getElementsByTagName("main")[0].style.height = document.getElementById("treatment").getElementsByTagName("main")[0].offsetHeight - document.getElementsByClassName("navbar")[0].offsetHeight + "px";
window.addEventListener("resize", function (e) {
    document.getElementById("treatment").getElementsByTagName("main")[0].style.height = document.getElementById("treatment").getElementsByTagName("main")[0].offsetHeight - document.getElementsByClassName("navbar")[0].offsetHeight + "px";
});

if (document.getElementsByClassName("section multiple-select")[0] != null) {
    Array.from(document.getElementsByClassName("option")).forEach(function (element) {
        element.addEventListener("click", function (e) {
            element.classList.toggle("selected")
        });
    });
} else {
    Array.from(document.getElementsByClassName("option")).forEach(function (element) {
        element.addEventListener("click", function (e) {
            Array.from(document.getElementsByClassName("option")).forEach(function (element) {
                element.classList.remove("selected")
            });
            element.classList.add("selected")
        });
    });
}

document.getElementsByClassName("next")[0].addEventListener("click", function (e) {
    if (document.getElementsByClassName("option selected")[0].getAttribute("data-url") != null) {
        window.location.href = document.getElementsByClassName("option selected")[0].getAttribute("data-url");
    }
});