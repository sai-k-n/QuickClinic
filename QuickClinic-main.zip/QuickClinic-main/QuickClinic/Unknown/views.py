from flask import render_template, Blueprint, redirect, url_for, request

Unknown = Blueprint("Unknown", __name__)


@Unknown.route("/unknown", methods=["GET", "POST"])
def Index():
    if request.method == "POST":
        noMovement = request.args.get("noMovement")
        return "this is some text" + str(noMovement)
    return render_template("unknown/unknown.html")
