from flask import render_template, Blueprint, redirect, url_for

Core = Blueprint("Core", __name__)


@Core.route("/")
def Index():
    return render_template("index.html")
