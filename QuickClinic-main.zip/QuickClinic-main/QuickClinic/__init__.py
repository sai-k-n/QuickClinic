from flask import Flask

app = Flask(__name__)

app.config["SECRET_KEY"] = "oafiojad98sa9gy7ag:)"

from QuickClinic.Core.views import Core
from QuickClinic.Known.views import Known
from QuickClinic.Unknown.views import Unknown

app.register_blueprint(Core)
app.register_blueprint(Known)
app.register_blueprint(Unknown)
